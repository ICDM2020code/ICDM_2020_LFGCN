import tensorflow as tf
from keras.callbacks import EarlyStopping, ModelCheckpoint, LambdaCallback
from keras.layers import Input, Dropout
from keras.models import Model
from keras.optimizers import Adam, SGD
from keras.regularizers import l2
from spektral_fix.datasets import citation
from spektral_fix.layers import FGSConv
from spektral_fix.utils import normalized_laplacian, rescale_laplacian, normalized_adjacency, degree_power
from sklearn.model_selection import GridSearchCV 
import scipy.sparse as sp
from scipy.sparse import csr_matrix
from scipy.sparse.linalg.eigen.arpack import eigsh
import pandas as pd
import numpy as np
from numpy import linalg
import os
os.environ['KMP_DUPLICATE_LIB_OK']='True'
import inspect
import networkx as nx
import operator
import collections
from matplotlib import pyplot as plt
from scipy.stats import powerlaw
import powerlaw

# Load data
dataset = 'cora'
adj, node_features, y_train, y_val, y_test, train_mask, val_mask, test_mask = citation.load_data(dataset)
np_adj = adj.toarray()
G = nx.from_numpy_matrix(np_adj)
degree_sequence_cora = sorted([d for n, d in G.degree()], reverse=True)  # degree sequence
#print(degree_sequence)
# print "Degree sequence", degree_sequence
#degreeCount = collections.Counter(degree_sequence)
#deg, cnt = zip(*degreeCount.items())

adj_2, node_features_2, y_train_2, y_val_2, y_test_2, train_mask_2, val_mask_2, test_mask_2 = citation.load_data('citeseer')
np_adj_2 = adj_2.toarray()
G_2 = nx.from_numpy_matrix(np_adj_2)
degree_sequence_citeseer = sorted([d for n, d in G_2.degree()], reverse=True)  # degree sequence

adj_3, node_features_3, y_train_3, y_val_3, y_test_3, train_mask_3, val_mask_3, test_mask_3 = citation.load_data('pubmed')
np_adj_3 = adj_3.toarray()
G_3 = nx.from_numpy_matrix(np_adj_3)
degree_sequence_pubmed = sorted([d for n, d in G_3.degree()], reverse=True)  # degree sequence

#print(powerlaw.fit(degree_sequence_cora))
#print(powerlaw.fit(degree_sequence_citeseer))
#print(powerlaw.fit(degree_sequence_pubmed))
results_1 = powerlaw.Fit(np.array(degree_sequence_cora))
results_2 = powerlaw.Fit(np.array(degree_sequence_citeseer))
results_3 = powerlaw.Fit(np.array(degree_sequence_pubmed))
#print(results.power_law.alpha) #3.702152925692742
print(results_2.power_law.alpha) # 4.097084837838821
print(results_3.power_law.alpha) # 4.336893705277014
#print(results.power_law.xmin) # 6


fig, ax = plt.subplots()

#plt.bar(deg, cnt, width=0.80, color='b')
plt.hist([degree_sequence_cora,degree_sequence_citeseer,degree_sequence_pubmed], bins = 50, density= True, color= ['b','r','lime']
         ,label=['b','r','lime'])
plt.title("Degree Histogram")
plt.legend(['Cora-ML','Citeseer','PubMed'])
plt.ylabel("Density")
plt.xlabel("Degree")
#ax.set_ylim([0,200])
#ax.set_xticks([d + 0.4 for d in deg])
#ax.set_xticklabels(deg)
'''
# draw graph in inset
plt.axes([0.4, 0.4, 0.5, 0.5])
Gcc = G.subgraph(sorted(nx.connected_components(G), key=len, reverse=True)[0])
pos = nx.spring_layout(G)
plt.axis('off')
nx.draw_networkx_nodes(G, pos, node_size=20)
nx.draw_networkx_edges(G, pos, alpha=0.4)
'''
#plt.show()


'''
# Based on edge betweenness 
G = nx.from_numpy_matrix(np_adj)
centrality = nx.edge_betweenness(G)
sorted_x = sorted(centrality.items(), key=operator.itemgetter(1)) # sort
sorted_x.reverse() # reverse

selection_input = int(np.ceil(2708 * 1/100)) # 1% highest edge betweenness #
for i in range(selection_input):
    np_adj[sorted_x[i][0][0], sorted_x[i][0][1]] = 0
    np_adj[sorted_x[i][0][1], sorted_x[i][0][0]] = 0
'''




'''
adj = csr_matrix(np_adj)

# Parameters
num_comp = 5
num_filter = 1
recurrent = None
N = node_features.shape[0]
F = node_features.shape[1]
n_classes = y_train.shape[1]
dropout_rate = 0.75
l2_reg = 5e-4
learning_rate = 1e-2
epochs = 2000
es_patience = 300
recur_num = 3 

# Normalized Laplacian
#fltr = normalized_adjacency(adj, symmetric=True)

# Generalized form
sigma = 0.5
degrees = np.float_power(np.array(adj.sum(1)), -sigma).flatten()
degrees[np.isinf(degrees)] = 0.
normalized_D = sp.diags(degrees, 0)
 
degrees_sec = np.float_power(np.array(adj.sum(1)), (sigma - 1)).flatten()
degrees_sec[np.isinf(degrees_sec)] = 0.
normalized_D_sec = sp.diags(degrees_sec, 0)
fltr = normalized_D.dot(adj)
fltr = fltr.dot(normalized_D_sec)

# For validation and test
sigma = 0.5
degrees = np.float_power(np.array(original_adj.sum(1)), -sigma).flatten()
degrees[np.isinf(degrees)] = 0.
normalized_D = sp.diags(degrees, 0)

degrees_sec = np.float_power(np.array(original_adj.sum(1)), (sigma - 1)).flatten()
degrees_sec[np.isinf(degrees_sec)] = 0.
normalized_D_sec = sp.diags(degrees_sec, 0)
ori_fltr = normalized_D.dot(original_adj)
ori_fltr = ori_fltr.dot(normalized_D_sec)


# Model definition
X_in = Input(shape=(F, ))
fltr_in = Input((N, ), sparse=True)

dropout_1 = Dropout(dropout_rate)(X_in)
graph_conv_1 = FGSConv(32,
                       num_comp=num_comp,
                       num_filter=num_filter,
                        recurrent=recurrent,
                        recur_num = recur_num,
                        dropout_rate=dropout_rate,
                        activation='elu',
                        gcn_activation='elu',
                        kernel_regularizer=l2(l2_reg))([dropout_1, fltr_in])


dropout_2 = Dropout(dropout_rate)(graph_conv_1)
graph_conv_2 = FGSConv(n_classes,
                       num_comp=2,
                       num_filter=1,
                        recurrent=recurrent,
                        recur_num = recur_num,
                        dropout_rate=dropout_rate,
                        activation='softmax',
                        gcn_activation=None,
                        kernel_regularizer=l2(l2_reg))([dropout_2, fltr_in])

# Build model
model = Model(inputs=[X_in, fltr_in], outputs=graph_conv_2)
optimizer = Adam(lr=learning_rate)
model.compile(optimizer=optimizer,
              loss='categorical_crossentropy',
              weighted_metrics=['acc'])
model.summary()

callbacks = [
    EarlyStopping(monitor='val_weighted_acc', patience=es_patience),
    ModelCheckpoint('best_model.h5', monitor='val_weighted_acc',
                    save_best_only=True, save_weights_only=True)
]

# Train model
validation_data = ([node_features, ori_fltr], y_val, val_mask)


model.fit([node_features, fltr],
          y_train,
          sample_weight=train_mask,
          epochs=epochs,
          batch_size=N,
          validation_data=validation_data,
          shuffle=False,
          callbacks=callbacks)

# Load best model

model.load_weights('best_model.h5')

# Evaluate model
print('Evaluating model.')
eval_results = model.evaluate([node_features, ori_fltr],
                              y_test,
                              sample_weight=test_mask,
                              batch_size=N)
print('Done.\n'
      'Test loss: {}\n'
      'Test accuracy: {}'.format(*eval_results))
'''


