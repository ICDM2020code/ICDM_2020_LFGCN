## Acknowledgements

Spektral is released under MIT license, available on the project's [Github](https://github.com/danielegrattarola/spektral).

The framework is developed and maintained primarily by Daniele Grattarola, from [Università della Svizzera Italiana (USI)](https://usi.ch), under the support of the Swiss National Science Foundation grant 200021\_172671. 